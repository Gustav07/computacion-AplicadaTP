#!/bin/bash

# Funci�n para mostrar la ayuda
function mostrar_ayuda() {
    echo "Uso: $0 -o <origen> -d <destino> [-help]"
    echo "Opciones:"
    echo "  -o     Directorio de origen a respaldar"
    echo "  -d     Directorio destino donde se guardar� el backup"
    echo "  -help  Muestra esta ayuda"
}

# Inicializar variables
origen=""
destino=""

# Parseo de argumentos
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    -o)
    origen="$2"
    shift
    shift
    ;;
    -d)
    destino="$2"
    shift
    shift
    ;;
    -help)
    mostrar_ayuda
    exit 0
    ;;
    *)
    echo "Opci�n no v�lida: $1"
    mostrar_ayuda
    exit 1
    ;;
esac
done

# Validar que origen y destino no est�n vac�os
if [ -z "$origen" ] || [ -z "$destino" ]; then
    echo "ERROR: Debe especificar directorio de origen y destino."
    mostrar_ayuda
    exit 1
fi

# Validar que los directorios existan
if [ ! -d "$origen" ]; then
    echo "ERROR: El directorio origen '$origen' no existe."
    exit 1
fi

if [ ! -d "$destino" ]; then
    echo "ERROR: El directorio destino '$destino' no existe."
    exit 1
fi

# Crear nombre del archivo de backup con fecha en formato YYYYMMDD
fecha=$(date +%Y%m%d)

# Extraer el nombre base del directorio origen para el archivo backup
nombre_origen=$(basename "$origen")

archivo_backup="${nombre_origen}_bkp_${fecha}.tar.gz"

# Crear backup
tar -czf "${destino}/${archivo_backup}" -C "$(dirname "$origen")" "$nombre_origen"

echo "Backup realizado correctamente en: ${destino}/${archivo_backup}"
